module.exports = {
name: "invite",
code: `
$getBotInvite`
}