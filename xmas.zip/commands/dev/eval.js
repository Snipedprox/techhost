module.exports = { 
   name: "eval",
  code:`
$eval[$message;yes;yes;yes;yes]
$onlyForIDs[$botOwnerID;896846485805744168;]
$deleteCommand
$onlyif[$charCount[$message]>0;specify somethig bruh]`
}