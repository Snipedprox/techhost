module.exports = {
name: "uc",
code: `

\`\`\`php
updated $commandscount commands\`\`\`

$updateCommands
`
}